export default {
  accent: '#FF4444',
  primary: '#FFF',
  textPrimary: '#41414D',
  textSecondary: '#737380',
  border: '#999',
  shadow: '#000',

}